﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Security.Permissions;
using Microsoft.Win32;

namespace WindowsFormsApplication2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        
        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            

            Form3 Form3 = new Form3();
            Form3.ShowDialog();
            this.Visible = false;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            //disable USB storage...
            Microsoft.Win32.Registry.SetValue(@"HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\USBSTOR", "Start", 4, Microsoft.Win32.RegistryValueKind.DWord);
            MessageBox.Show("USB Port Blocked");

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            //enable USB storage...
            Microsoft.Win32.Registry.SetValue(@"HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\USBSTOR", "Start", 3, Microsoft.Win32.RegistryValueKind.DWord);
            MessageBox.Show("USB Port Unblocked");
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void Form2_MouseDoubleClick(object sender, MouseEventArgs e)
        {

        }
    }
}
