﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        protected void Displaynotify()
        {
            try
            {

                notifyIcon1.Text = "USB Port Blocker";
                notifyIcon1.Visible = true;
                notifyIcon1.BalloonTipTitle = "USB Port Blocker runing";
                notifyIcon1.BalloonTipText = "";
                notifyIcon1.ShowBalloonTip(100);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Sorry We Can't Run Program ");
            }

        }
        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
                  
             if (textBox2.Text == Properties.Settings.Default.pass)
                {
                    this.Visible = false;
                    Form2 Form2 = new Form2();
                    Form2.ShowDialog();
                   }
             else { MessageBox.Show("Please Insert True Password"); }
            }

        
    }
}
